*"Alert! Defense barriers have been breached, we have a horde of enemies heading in your direction. It was a pleasure meeting you! Hope you will get an honourable death."*

I thought it a little wierd that nobody had done this yet so I took it upon myself. Found it a bit hard to find fitting clips for certain circumstances but overall I'm happy enough with it. 